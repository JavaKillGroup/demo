package org.smart4j.sample.service;

public interface LogService {

    void log(String description);
}
