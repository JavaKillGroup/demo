package org.mvc.ServiceImpl;

import java.util.List;
import java.util.Map;

import org.mvc.entity.User;
import org.mvc.service.UserService;
import org.plugin.cache.annotation.CacheClear;
import org.plugin.cache.annotation.CachePut;
import org.smart.framework.orm.DataSet;
import org.smart.framework.tx.annotation.Service;
import org.smart.framework.tx.annotation.Transaction;

@Service
public class UserServiceImpl implements UserService {

	@Override
	@CachePut("user_list_cache")
	public List<User> findUserList() {
		return DataSet.selectList(User.class);
	}

	@Override
	@CacheClear("user_cache")
	public User findUser(int id) {
		return DataSet.select(User.class, "id = ?", id);
	}

	@Override
	@Transaction
	@CacheClear({ "user_list_cache", "user_cahce" })
	public boolean saveUser(Map<String, Object> fieldMap) {
		return DataSet.insert(User.class, fieldMap);
	}

	@Override
	@Transaction
	@CacheClear({ "user_list_cache", "user_cache" })
	public boolean updateUser(int id, Map<String, Object> fieldMap) {
		return DataSet.update(User.class, fieldMap, "id = ?", id);
	}

	@Override
	@Transaction
	@CacheClear({ "user_list_cache", "user_cache" })
	public boolean deleteUser(int id) {
		return DataSet.delete(User.class, "id = ?", id);
	}

}
