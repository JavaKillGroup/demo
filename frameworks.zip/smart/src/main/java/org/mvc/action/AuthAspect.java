package org.mvc.action;
import java.lang.reflect.Method;

import org.mvc.entity.User;
import org.smart.framework.aop.AspectProxy;
import org.smart.framework.aop.annotation.Aspect;
import org.smart.framework.aop.annotation.AspectOrder;
import org.smart.framework.ioc.annotation.Bean;
import org.smart.framework.mvc.DataContext;
import org.smart.framework.mvc.fault.AuthcException;

/**
 * 安全访问控制
 * @author TY
 * @Time 2017年9月18日 下午3:21:36
 */
@Bean
@Aspect(pkg = "org.mvc.action",cls="UserAction")
@AspectOrder(0)
public class AuthAspect extends AspectProxy {

	@Override
	public boolean intercept(Class<?> cls, Method method, Object[] params) {
		String className = cls.getSimpleName();
		String methodName = method.getName();
		return !(className.equals("UserAction") && (methodName.equals("login") || methodName.equals("logout")));
	}

	@Override
	public void before(Class<?> cls, Method method, Object[] params) throws Exception {
		User user = DataContext.Session.get("user");
		if (user == null) {
			throw new AuthcException("没有登录！！");
		}
	}
}
