package org.mvc.action;

import java.util.List;
import java.util.Map;

import org.mvc.entity.User;
import org.mvc.service.UserService;
import org.smart.framework.ioc.annotation.Inject;
import org.smart.framework.mvc.DataContext;
import org.smart.framework.mvc.annotation.Action;
import org.smart.framework.mvc.annotation.Request;
import org.smart.framework.mvc.bean.Params;
import org.smart.framework.mvc.bean.Result;
import org.smart.framework.mvc.bean.View;

@Action
public class UserAction {
	@Inject
	private UserService userService;

	@Request.Get("/users")
	public View index() {
		List<User> userList = userService.findUserList();
		DataContext.Request.put("userList", userList);
		return new View("user.jsp");
	}

	@Request.Get("/user")
	public View create() {
		return new View("user_create.jsp");
	}

	@Request.Post("/user")
	public Result save(Params params) {
		Map<String, Object> fieldMap = params.getFieldMap();
		boolean result = userService.saveUser(fieldMap);
		return new Result(result);
	}

	@Request.Get("/user/{id}")
	public View edit(int id) {
		User user = userService.findUser(id);
		DataContext.Request.put("user", user);
		return new View("user_edit.jsp");
	}

	@Request.Put("/user/{id}")
	public Result update(int id, Params params) {
		Map<String, Object> fieldMap = params.getFieldMap();
		boolean result = userService.updateUser(id, fieldMap);
		return new Result(result);
	}

	@Request.Delete("/user/{id}")
	public Result delete(int id) {
		boolean result = userService.deleteUser(id);
		return new Result(result);
	}
}
