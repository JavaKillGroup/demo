package org.mvc.service;

import java.util.List;
import java.util.Map;

import org.mvc.entity.User;
import org.smart.framework.tx.annotation.Service;

public interface UserService {

	List<User> findUserList();
	
	User findUser(int id);
	
	boolean saveUser(Map<String, Object> fieldMap);

    boolean updateUser(int id, Map<String, Object> fieldMap);

    boolean deleteUser(int id);
}
